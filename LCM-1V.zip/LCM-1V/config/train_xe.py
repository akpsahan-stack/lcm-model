"""
LCM — Linear Consciousness Model
Configuration: XE-Architecture

This file defines ALL hyperparameters for one training run.
Loaded by train.py via:
    python train.py config/train_xe.py

Override any value from CLI:
    python train.py config/train_xe.py --n_embd=4000 --batch_size=4

Three preset profiles:
    lcm-small   — fits single T4  (n_embd=768,  ~85M params)
    lcm-medium  — fits dual T4    (n_embd=2000, ~500M params)
    lcm-large   — needs A100×4    (n_embd=4000, ~1.2B params)

Mathematical formula parameters (Ramanujan / Prime / Ellipse)
are defined below and consumed by model.py.
"""

import math

# ═══════════════════════════════════════════════════════════
# SELECT PROFILE
# ═══════════════════════════════════════════════════════════

profile = 'lcm-small'  # 'lcm-small' | 'lcm-medium' | 'lcm-large'

# ═══════════════════════════════════════════════════════════
# MODEL ARCHITECTURE
# ═══════════════════════════════════════════════════════════

# --- small: single T4 / dual T4, ~85M params ---
if profile == 'lcm-small':
    n_layer          = 12
    n_embd           = 768
    block_size       = 1024
    ffn_ratio        = 4.0
    batch_size       = 16
    gradient_accumulation_steps = 4
    learning_rate    = 6e-4
    max_iters        = 100000
    use_fsdp         = False
    use_gradient_checkpointing = False

# --- medium: dual T4, ~500M params ---
elif profile == 'lcm-medium':
    n_layer          = 24
    n_embd           = 2000
    block_size       = 1024
    ffn_ratio        = 4.0
    batch_size       = 4
    gradient_accumulation_steps = 16
    learning_rate    = 3e-4
    max_iters        = 200000
    use_fsdp         = True
    use_gradient_checkpointing = True

# --- large: A100×4, ~1.2B params ---
elif profile == 'lcm-large':
    n_layer          = 32
    n_embd           = 4000
    block_size       = 1024
    ffn_ratio        = 4.0
    batch_size       = 2
    gradient_accumulation_steps = 32
    learning_rate    = 2e-4
    max_iters        = 300000
    use_fsdp         = True
    use_gradient_checkpointing = True

else:
    raise ValueError(f"Unknown profile: {profile}")

# ═══════════════════════════════════════════════════════════
# VOCABULARY
# ═══════════════════════════════════

vocab_size         = 50304      # 50257 (GPT-2) padded to nearest 64
image_vocab_size   = 1024       # VQGAN codebook size
bias               = False      # bias in Linear and LayerNorm layers
dropout            = 0.0        # 0 for pretraining, 0.1+ for finetuning

# ═══════════════════════════════════════════════════════════
# RAMANUJAN ELLIPSE PARAMETERS
# ═══════════════════════════════════════════════════════════════════════════════════
#
# Controls A matrix initialization in RecurrentLinearScan.
# Each hidden dimension i gets a unique ellipse (a_i, b_i).
# Ramanujan perimeter P_i determines that dimension's decay rate.
#
# Formula:
#   h = ((a - b) / (a + b))²
#   P ≈ π(a + b)(1 + 3h / (10 + √(4 - 3h)))
#
# Parameters below control how (a, b) are swept across dimensions.

# sweep method: 'sinusoidal' creates smooth variation
ellipse_sweep_method = 'sinusoidal'

# semiaxis ranges for the sweep
# a_i ∈ [ellipse_a_min, ellipse_a_max]
# b_i ∈ [ellipse_b_min, ellipse_b_max]
ellipse_a_min = 0.1
ellipse_a_max = 1.0
ellipse_b_min = 0.1
ellipse_b_max = 1.0

# phase offset between a and b sweeps (radians)
# pi/4 gives maximum diversity (a and b are maximally decorrelated)
ellipse_phase_offset = math.pi / 4

# resulting A matrix decay range (after Ramanujan → normalized)
# A values will be clamped to [decay_min, decay_max]
# decay close to 1.0 = long memory, close to 0 = short memory
ellipse_decay_min = 0.5
ellipse_decay_max = 0.999

# ═══════════════════════════════════════════════════════════
# PRIME NUMBER GATE PARAMETERS
# ═══════════════════════════════════════════════════════════
#
# Controls the selective gate in RecurrentLinearScan.
# At prime-numbered positions, the gate gets a boost,
# allowing more new input to enter the hidden state.
# At composite positions, the gate favors retaining past state.
#
# Analogy (Buddhist "Sati" / mindfulness):
#   Prime positions =(x + 0.5 moments of clear awareness
#   → gate opens wide, present-moment input admitted
#   Composite positions = habitual/conditioned moments
#   → gate favors continuity, past state persists

# initial gate bias (negative = conservative, favor past state)
# -1.0 means gate sigmoid starts near 0.27 (mostly closed)
prime_gate_init_bias = -1.0

# boost multiplier at prime positions
# 0.5 means prime positions get sigmoid*1) instead of sigmoid(x)
prime_boost_strength = 0.5

# gradient modulation at prime steps (experimental, 0 = off)
# if > 0, gradients are scaled by (1 + strength) at prime-numbered steps
prime_grad_modulation = 0.0

# ═══════════════════════════════════════════════════════════
# ELLIPSE SCALING PARAMETERS
# ═══════════════════════════════════════════════════════════
#
# Per-dimension input scaling from ellipse geometry.
# Dimensions with large perimeter get faster input scaling.
# Dimensions with small perimeter get slower input scaling.
#
# This creates a natural multi-timescale representation:
#   some dims: fast-updating, short-term memory
#   some dims: slow-updating, long-term memory

# input scale formula: scale_i = 1.0 - decay_i
# (complementary to decay: fast decay → large input, and vice versa)
# this is set automatically in model.py from ellipse dynamics
# no additional parameters needed here

# ═══════════════════════════════════════════════════════════
# MULTIMODAL
# ═══════════════════════════════════════════════════════════

use_multimodal       = True       # dual input/output heads
image_size           = 256        # square resolution for image tokens
image_codec_type     = 'simple_vq'  # 'simple_vq' | 'vqgan' | 'random_codebook'
image_codec_ckpt     = 'checkpoints/vq.pt'  # pre-trained VQ-VAE weights

# loss weighting (when multimodal data is used)
text_loss_weight     = 0.7
image_loss_weight    = 0.3

# training curriculum (set 0.0 to skip a phase)
# phase 1: text-only, phase 2: add images gradually
curriculum_image_start_iter = 5000   # start mixing images after this step
curriculum_image_ratio_start = 0.0  # initial image ratio
curriculum_image_ratio_end   = 0.3  # final image ratio

# ═══════════════════════════════════════════════════════════
# DATA
# ═══════════════════════════════════════════════════════════

dataset              = 'openwebtext'  # dataset name under data/
use_multimodal_data  = False          # True when multimodal data is prepared

# ═══════════════════════════════════════════════════════════
# OPTIMIZER (AdamW)
# ═══════════════════════════════════════════════════════════

weight_decay         = 0.1
beta1                = 0.9
beta2                = 0.95
grad_clip            = 1.0

# ═══════════════════════════════════════════════════════════
# LEARNING RATE SCHEDULE (cosine with warmup)
# ═══════════════════════════════════════════════════════════

decay_lr             = True
warmup_iters         = 2000
lr_decay_iters       = max_iters    # ~= max_iters per Chinchilla
min_lr               = learning_rate / 10

# ═══════════════════════════════════════════════════════════
# EVALUATION & CHECKPOINTING
# ═══════════════════════════════════════════════════════════

out_dir              = f'out-lcm-{profile}'
eval_interval        = 2000
eval_iters           = 200
eval_only            = False
always_save_checkpoint = True
init_from            = 'scratch'    # 'scratch' or 'resume'

# ═══════════════════════════════════════════════════════════
# LOGGING
# ═══════════════════════════════════════════════════════════

log_interval         = 1
wandb_log            = False
wandb_project        = f'lcm-{profile}'
wandb_run_name       = f'{profile}-run'

# ═══════════════════════════════════════════════════════════
# SYSTEM / HARDWARE
# ═══════════════════════════════════════════════════════════

backend              = 'nccl'       # 'nccl' for GPU, 'gloo' for CPU
device               = 'cuda'
dtype                = 'bfloat16'   # 'float32' | 'bfloat16' | 'float16'
compile              = True         # torch.compile (PyTorch 2.0+)

# ═══════════════════════════════════════════════════════════
# PARAMETER COUNT ESTIMATE
# ═══════════════════════════════════════════════════════════

def _estimate_params():
    """Quick param count estimate (printed at load time)."""
    D = n_embd
    # per block: B_proj + C_proj + gate_proj + gate_norm + FFN(3 matrices)
    # B/C/gate: D×D each = 3D²
    # gate_norm: 2D
    # FFN (SwiGLU): gate(D, 4D) + up(D, 4D) + down(4D, D) = 12D²
    per_block = 3 * D * D + 12 * D * D + 2 * D  # 15D² + 2D
    # embeddings: text_wte + image_wte + wpe
    embed_params = (vocab_size + image_vocab_size + block_size) * D
    # output heads: lm_head + image_head (tied to embeddings, so ~0 extra)
    total = n_layer * per_block + embed_params
    return total

_est = _estimate_params()
print(f"[{profile}] n_layer={n_layer}, n_embd={n_embd}, "
      f"ffn_ratio={ffn_ratio}, block_size={block_size}")
print(f"[{profile}] estimated params: {_est/1e6:.1f}M")

# ═══════════════════════════════════════════════════════════
# VRAM ESTIMATE
# ═══════════════════════════════════════════════════════════

def _estimate_vram_gb():
    """Rough VRAM estimate for fp16 training with Adam."""
    param_bytes = _est * 2                     # fp16 params
    grad_bytes  = _est * 2                     # fp16 gradients
    adam_bytes  = _est * 4 * 2                 # fp32 m + v states
    # activations (rough: batch × seq × dim × layers × bytes)
    act_bytes   = batch_size * block_size * n_embd * n_layer * 2
    # gradient checkpointing halves activation memory
    if use_gradient_checkpointing:
        act_bytes //= 2
    total_bytes = param_bytes + grad_bytes + adam_bytes + act_bytes
    return total_bytes / (1024 ** 3)

_vram = _estimate_vram_gb()
print(f"[{profile}] estimated VRAM: {_vram:.1f} GB")

# warn if likely to exceed T4 limits
if _vram > 30 and not use_fsdp:
    print(f"[{profile}] WARNING: {_vram:.1f} GB may exceed dual T4 (32 GB). "
          f"Consider use_fsdp=True or smaller n_embd.")

# ═══════════════════════════════════════════════════════════
# EFFECTIVE BATCH SIZE REPORT
# ═══════════════════════════════════════════════════════════

def _estimate_effective_batch():
    """Effective tokens per optimization step."""
    # assume 2 GPUs for dual T4
    world_size = 2
    return gradient_accumulation_steps * world_size * batch_size * block_size

_eff_batch = _estimate_effective_batch()
print(f"[{profile}] effective batch: {_eff_batch:,} tokens/step")

# ═══════════════════════════════════════════════════════════
# MATHEMATICAL FORMULA SUMMARY (logged for reproducibility)
# ═══════════════════════════════════════════════════════════

_formula_summary = f"""
╔══════════════════════════════════════════════════════════════╗
║  LCM — Mathematical Formula Summary                         ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  Recurrence:  h_t = gate_t ⊙ (A ⊙ h_{{t-1}})                ║
║                     + (1 − gate_t) ⊙ (B · x_t)              ║
║                                                              ║
║  Ramanujan Ellipse Perimeter:                                ║
║    h = ((a - b) / (a + b))²                                  ║
║    P ≈ π(a+b)(1 + 3h / (10 + √(4 − 3h)))                   ║
║                                                              ║
║  A matrix (diagonal):                                        ║
║    A_i = normalize(P_i) into [{ellipse_decay_min}, {ellipse_decay_max}]   ║
║    where P_i = Ramanujan(a_i, b_i)                           ║
║    and (a_i, b_i) sweep sinusoidally across dims             ║
║                                                              ║
║  Gate (prime-aware):                                         ║
║    gate_t = clamp(σ(W·x_t + boost · 𝟙[is_prime(t)]))       ║
║    boost = {prime_boost_strength} at prime positions                      ║
║    init_bias = {prime_gate_init_bias}                             ║
║                                                              ║
║  Input scaling:                                              ║
║    scale_i = 1 − A_i   (complementary to decay)              ║
║                                                              ║
║  FFN: SwiGLU(x) = Silu(x·W_gate) ⊙ (x·W_up) · W_down      ║
║                                                              ║
║  Analogy (Viññāṇa):                                          ║
║    h_{{t-1}} = atīta citta  (departing consciousness)         ║
║    x_t     = phassa         (sense-door contact)             ║
║    gate_t  = sati           (mindfulness)                    ║
║    h_t     = uppāda citta   (arising consciousness)          ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
"""
print(_formula_summary)